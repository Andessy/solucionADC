CREATE TABLE DataIddleTime
(
Username varchar(50) not null,
IdActivity int not null,
Activity varchar(100) not null,
Customer varchar(100) not null,
KeyPress int not null,
DateKey varchar (20) not null,
DateKeyInt bigint not null,
StartDateTime varchar (20) not null,
EndDateTime varchar(20) not null,
DurationActivity  int not null
);