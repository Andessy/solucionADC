DELIMITER $$
CREATE DEFINER=`root`@`%` PROCEDURE `TiemposMuertos`()
BEGIN

	drop temporary table ADC.grupoKey1;
	drop temporary table ADC.grupoKey2;
	drop table ADC.IddleTimes;
    
	CREATE TEMPORARY TABLE ADC.grupoKey1(id MEDIUMINT NOT NULL AUTO_INCREMENT, 
    username VARCHAR(30) NOT NULL, 
    idactivity int, 
    activity varchar(30),
    datekey VARCHAR(20), 
    cantidad int,
    PRIMARY KEY (id));
    
    INSERT INTO ADC.grupoKey1 (username, idactivity, activity, datekey, cantidad)
    SELECT username, idactivity, activity, datekeyInt, count(*) FROM ADC.DataIddleTime
	group by username, idactivity, activity, datekey
    order by username, datekeyInt;
    
    CREATE temporary table ADC.grupoKey2 
    select * from ADC.grupoKey1;
    
    CREATE TABLE ADC.IddleTimes(
    Username VARCHAR(30) NOT NULL, 
    Activity varchar(30),
    Iddletime int);
    
	INSERT INTO ADC.IddleTimes (Username, Activity, Iddletime)
    select d.username, d.activity, timestampdiff(MINUTE, STR_TO_DATE(g.datekey,'%Y%m%d%H%i') , STR_TO_DATE(d.datekey,'%Y%m%d%H%i')) 
    from ADC.grupoKey1 d
    left outer join ADC.grupoKey2 g 
    on d.id =g.id+1 and d.username = g.username;
END$$
DELIMITER ;
