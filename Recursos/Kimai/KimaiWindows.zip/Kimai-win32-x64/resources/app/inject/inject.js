var data_tracking =  {
      platform: "windows",
      appID:"PwAYiwDKY3CDvajgMs4a",
      url:"http://3.133.17.122/es/login",
      appname:"Kimai"
    };
    window.dataLayer = window.dataLayer || [];
    dataLayer.push(data_tracking);(function (w, d, s, l, i) {  w[l] = w[l] || [];  w[l].push({  'gtm.start': new Date().getTime(), event: 'gtm.js', }); let f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? `&l=${l}` : ''; j.async = true; j.src = `https://www.googletagmanager.com/gtm.js?id=${i}${dl}`; f.parentNode.insertBefore(j, f); }(window, document, 'script', 'dataLayer', 'GTM-N9XW463'));